# Detect circRNAs from chimera
